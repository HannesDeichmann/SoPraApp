> Als *Rolle* möchte ich *Ziel/Wunsch*, um *Nutzen*.

## Ausführlichere Beschreibung

*bei Bedarf*

## Akzeptanztests

- Akzeptanztests: 
    - *TODO (Beschreibung von Testfällen die das erwartete Verhalten der gesamten Implementable Story überprüfen.)*
    - *TODO*
    - *TODO*

## Meta
- Aufwandsschätzung: [0-100] Story Points
- Enthaltene Tasks: 
    - [ ] [Task 1](#)
    - [ ] [Task 2](#)
    - [ ] [Task 3](#)