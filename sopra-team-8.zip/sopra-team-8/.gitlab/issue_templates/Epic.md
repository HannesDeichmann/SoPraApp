> Als *Rolle* möchte ich *Ziel/Wunsch*, um *Nutzen*.

## Ausführlichere Beschreibung

*Pflicht*

## Enthaltene Features

- [Feature 1](#)
- [Feature 2](#)
- [Feature 3](#)
