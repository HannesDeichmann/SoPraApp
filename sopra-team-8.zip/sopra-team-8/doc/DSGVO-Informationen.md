#DSGVO-relevante Informationen
im SoPra WS19/20
Team-Nr: 8
App-Name: Wächter-App

In dieser App werden folgende DSGVO-relevanten Daten benutzt:

* Vor und Nachname des Wachmanns
	* Unerlässlich, um Wachmänner verantwortlich machen zu können
	* Speicherort: Lokale Datenbank
	* Verschlüsselt: ja
	* Übermittlung an andere Apps, nein da die App ohne Server funktioniert